package org.zerock.domain;

import lombok.Data;

@Data
public class Ticket {
	private Integer tno;
	private String owner;
	private String grade;
}
